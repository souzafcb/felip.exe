# Materiais identificados e ainda offline

Estes arquivos ligados à produção FEZ foram identificados no OneDrive, mas estavam disponíveis apenas como placeholders de nuvem no momento da organização. Eles não foram substituídos por conteúdo inferido.

## Prompts e textos

- `historico_completo_mostre_memoria_prompt.md` — 25.023 bytes
- `FEZ_letras_ajustadas_plataformas.md` — 10.223 bytes
- `A_cobrar_letra.txt` — 4.222 bytes
- `FEZ — Caderno de Letras 2024 Portfólio Musical.html` — 39.348 bytes

Quando estiverem hidratados, os três primeiros devem entrar em `processo-criativo/fontes/`; o portfólio HTML deve entrar em `arquivo/legado/`.

## Sessões e áudio

- `FEZ.aup3` — 180.871.168 bytes
- `Yô_FEZ.wav` — 43.399.852 bytes
- `DNAi_Single DNAi_FEZ_reference_24bit_44hz_target-14.wav` — 70.881.714 bytes

Esses arquivos devem ser adicionados por Git LFS. O repositório já contém regras LFS para `.aup3`, `.wav`, `.flac` e `.mp3`.

## Materiais locais já incorporados

- `FEZ_Caderno_de_Letras.docx` foi preservado em `arquivo/legado/`.
- `FEZ — Letras.pdf` foi preservado em `arquivo/legado/`.
- `FEZ.png` é idêntico à thumbnail já presente em `public/assets/images/FEZ_thumbnail_social.png`, portanto não foi duplicado.
