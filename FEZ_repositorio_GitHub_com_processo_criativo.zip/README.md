# FEZ_

Arquivo digital de produção artística de FEZ: manifesto, letras, documentos editoriais e site.

## Site

O site está em `public/` e reúne o manifesto **Criar no Caldo do Mundo** e o caderno com 13 letras. A identidade visual combina linguagem editorial, rap contemporâneo e referências discretas a código e terminal.

- Página principal: `public/index.html`
- Thumbnail social: `public/assets/images/FEZ_thumbnail_social.png`
- Favicon: `public/assets/images/FEZ_favicon.svg`
- Idioma: português do Brasil
- Domínio previsto: `fez.etc.br`

## Acervo

```text
FEZ_repositorio_GitHub/
├── public/                 site pronto para publicação
│   ├── index.html
│   └── assets/images/
├── documentos/
│   ├── pdf/                versões finais para leitura e impressão
│   └── docx/               versões editáveis
├── arquivo/
│   ├── originais/          PDFs que serviram como fonte
│   ├── legado/             versões anteriores preservadas
│   └── FEZ_Carta_e_Manifesto_Versao_Diagramada.docx
├── processo-criativo/
│   ├── suno/               tags e direções musicais recuperadas
│   ├── METODO_RECURSIVO.md
│   └── MATERIAIS_OFFLINE.md
├── tools/                  scripts de construção e verificação
├── requirements.txt
└── README.md
```

## Publicação no Cloudflare Pages

Conecte este repositório ao Cloudflare Pages e use:

- Comando de build: deixar vazio
- Diretório de saída: `public`
- Domínio personalizado: `fez.etc.br`

O site é estático e não precisa de framework nem processo de compilação.

## Ferramentas de produção

Para recriar ou conferir os documentos localmente:

```bash
python -m venv .venv
python -m pip install -r requirements.txt
python tools/build_fez_documents.py
python tools/validate_fez_outputs.py
```

Os scripts usam caminhos relativos ao repositório. Os originais permanecem em `arquivo/originais/`.

## Processo criativo

As instruções de produção não foram tratadas como resíduos técnicos. As tags de estrutura, timbre, interpretação, andamento e arranjo usadas no processo com Suno estão preservadas em `processo-criativo/suno/TAGS_E_DIRECOES.md`. O fluxo de semente, geração, escuta, reescrita, stems e DAW está documentado em `processo-criativo/METODO_RECURSIVO.md`.

Arquivos de áudio e projetos maiores que venham a ser adicionados usam Git LFS. Consulte `processo-criativo/MATERIAIS_OFFLINE.md` para os materiais identificados no OneDrive que ainda precisam ser hidratados localmente.

## Direitos

Textos, letras, identidade visual e demais conteúdos artísticos pertencem a FEZ. O conteúdo não é disponibilizado sob licença aberta. Consulte o autor antes de copiar, adaptar ou redistribuir.
