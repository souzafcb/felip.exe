from __future__ import annotations

import base64
import gzip
import hashlib
import hmac
import json
import re
import struct
import time
import urllib.parse
import urllib.request
import urllib.error


SEARCHES = [
    "Tempoder",
    "Panos Brancos, Peles Frias",
    "Boa tarde Majestade",
    "O Ramo da Bencideira",
    "Aqui de Cima",
    "A cobrar",
    "MOSTRE",
    "Por um triz",
    "Alquimista Griot",
    "LAGRIMÁ — NANÃ",
    "YÔ / IO / RUA / IORUBÁ",
    "DELEITE",
    "REMAR MARÉ",
]


def get(url: str, headers: dict[str, str] | None = None) -> bytes:
    request = urllib.request.Request(url, headers=headers or {"User-Agent": "Mozilla/5.0"})
    try:
        response = urllib.request.urlopen(request, timeout=45)
    except urllib.error.HTTPError as error:
        raise RuntimeError(f"HTTP {error.code}: {error.read().decode('utf-8', 'replace')}") from error
    with response:
        payload = response.read()
        if payload.startswith(b"\x1f\x8b"):
            payload = gzip.decompress(payload)
        return payload


def totp(secret: bytes, timestamp_ms: int) -> str:
    counter = timestamp_ms // 1000 // 30
    digest = hmac.new(secret, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = (struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF) % 1_000_000
    return f"{code:06d}"


page = get("https://open.spotify.com/search/Tempoder%20FEZ").decode("utf-8")
script_url = re.search(
    r'https://open\.spotifycdn\.com/cdn/build/mobile-web-player/mobile-web-player\.[a-f0-9]+\.js',
    page,
).group(0)
bundle = get(script_url).decode("utf-8")
match = re.search(r"let RI=\[\{secret:(['\"])(.*?)\1,version:(\d+)", bundle)
encoded_secret, version = match.group(2), int(match.group(3))
encoded_secret = bytes(encoded_secret, "utf-8").decode("unicode_escape")
decoded_secret = "".join(chr(ord(char) ^ (index % 33 + 9)) for index, char in enumerate(encoded_secret))
secret = decoded_secret.encode("utf-8")

server_time = int(json.loads(get("https://open.spotify.com/api/server-time"))["serverTime"])
params = {
    "reason": "init",
    "productType": "mobile-web-player",
    "totp": totp(secret, int(time.time() * 1000)),
    "totpServer": totp(secret, server_time * 1000),
    "totpVer": str(version),
}
token_url = "https://open.spotify.com/api/token?" + urllib.parse.urlencode(params)
token = json.loads(get(token_url))["accessToken"]

results = []
for title in SEARCHES:
    query = urllib.parse.urlencode({"q": f'track:"{title}" artist:FEZ', "type": "track", "market": "BR", "limit": 10})
    data = json.loads(
        get(
            "https://api.spotify.com/v1/search?" + query,
            {"Authorization": f"Bearer {token}", "User-Agent": "Mozilla/5.0"},
        )
    )
    matches = []
    for item in data.get("tracks", {}).get("items", []):
        matches.append(
            {
                "title": item["name"],
                "artists": [artist["name"] for artist in item["artists"]],
                "url": item["external_urls"]["spotify"],
                "release": item["album"]["release_date"],
                "label": item["album"].get("label"),
            }
        )
    results.append({"query": title, "matches": matches})

print(json.dumps(results, ensure_ascii=False, indent=2))
